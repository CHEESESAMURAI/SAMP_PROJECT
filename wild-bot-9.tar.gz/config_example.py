# config_example.py
# Скопируйте этот файл в config.py и заполните своими ключами

# Telegram Bot Configuration
BOT_TOKEN = "your_telegram_bot_token_here"
ADMIN_ID = 123456789  # Ваш Telegram ID

# API Keys
SERPER_API_KEY = "your_serper_api_key_here"
OPENAI_API_KEY = "your_openai_api_key_here"
MPSTATS_API_KEY = "your_mpstats_api_key_here"
YOUTUBE_API_KEY = "your_youtube_api_key_here"
VK_SERVICE_KEY = "your_vk_service_key_here" 