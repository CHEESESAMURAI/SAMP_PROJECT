# 🚀 Развертывание Wild Analytics Dashboard через PM2

## ✅ **PM2 - Профессиональное управление процессами**

PM2 обеспечивает:
- 🔄 Автоматический перезапуск при сбоях
- 📊 Мониторинг в реальном времени
- 📋 Централизованное логирование
- 🔧 Управление несколькими процессами
- 💾 Сохранение конфигурации

## 📁 **Структура для PM2:**

```
WILD_BOT_9/
├── start_pm2.sh           # 🚀 Запуск через PM2
├── stop_pm2.sh            # 🛑 Остановка через PM2
├── view_pm2_logs.sh       # 📋 Просмотр логов
├── ecosystem.config.js    # ⚙️ Конфигурация PM2
├── requirements.txt       # 📦 Python зависимости
├── web-dashboard/         # 🔧 Backend
└── wild-analytics-web/    # 🌐 Frontend
```

## 🚀 **Быстрый запуск на VPS (93.127.214.183):**

### 1. Установка PM2
```bash
# Установка PM2 глобально
npm install -g pm2

# Установка serve для frontend
npm install -g serve
```

### 2. Подготовка проекта
```bash
# Создание conda среды
conda create -n wildbot python=3.9 -y
conda activate wildbot

# Установка Python зависимостей
pip install -r requirements.txt

# Установка Node.js зависимостей
cd wild-analytics-web
npm install
npm run build
cd ..
```

### 3. Создание папки для логов
```bash
mkdir -p logs
```

### 4. Запуск через PM2
```bash
# Дать права на выполнение
chmod +x start_pm2.sh stop_pm2.sh view_pm2_logs.sh

# Запуск проекта
./start_pm2.sh
```

## 🔧 **Альтернативные способы запуска:**

### Способ 1: Через ecosystem.config.js
```bash
pm2 start ecosystem.config.js
```

### Способ 2: Прямые команды
```bash
# Backend
pm2 start "python3 main.py" \
  --name wild-backend \
  --cwd /root/WILD_BOT_9/web-dashboard/backend \
  --interpreter /root/miniconda3/envs/wildbot/bin/python3

# Frontend
pm2 start serve \
  --name wild-frontend \
  -- -s build -l 3000 \
  --cwd /root/WILD_BOT_9/wild-analytics-web
```

## 🌐 **Результат:**

После успешного запуска:
- **Frontend**: http://93.127.214.183:3000
- **Backend**: http://93.127.214.183:8000
- **API Docs**: http://93.127.214.183:8000/docs

## 🔧 **Управление через PM2:**

```bash
# Статус процессов
pm2 status

# Просмотр логов
pm2 logs
pm2 logs wild-backend
pm2 logs wild-frontend

# Перезапуск
pm2 restart all
pm2 restart wild-backend
pm2 restart wild-frontend

# Остановка
pm2 stop all
pm2 stop wild-backend
pm2 stop wild-frontend

# Удаление
pm2 delete all
pm2 delete wild-backend
pm2 delete wild-frontend

# Мониторинг в реальном времени
pm2 monit

# Сохранение конфигурации
pm2 save

# Автозапуск при перезагрузке
pm2 startup
pm2 save
```

## 📊 **Мониторинг и логи:**

### Просмотр логов
```bash
# Все логи
pm2 logs

# Логи конкретного процесса
pm2 logs wild-backend --lines 50
pm2 logs wild-frontend --lines 50

# Логи в реальном времени
pm2 logs --follow
```

### Мониторинг ресурсов
```bash
# Интерактивный мониторинг
pm2 monit

# Статистика
pm2 show wild-backend
pm2 show wild-frontend
```

## 🔍 **Устранение неполадок:**

### Проблема: Процесс не запускается
```bash
# Проверить логи
pm2 logs wild-backend --lines 100

# Проверить статус
pm2 status

# Перезапустить
pm2 restart wild-backend
```

### Проблема: Conda не найдена
```bash
# Обновить путь к Python в ecosystem.config.js
# или использовать полный путь в команде
pm2 start "/root/miniconda3/envs/wildbot/bin/python3 main.py" \
  --name wild-backend \
  --cwd /root/WILD_BOT_9/web-dashboard/backend
```

### Проблема: Порт занят
```bash
# Остановить все процессы
pm2 stop all
pm2 delete all

# Проверить порты
lsof -i :3000 -i :8000

# Запустить заново
./start_pm2.sh
```

## 📋 **Полезные команды:**

```bash
# Просмотр всех процессов
pm2 list

# Информация о процессе
pm2 show wild-backend

# Перезагрузка PM2
pm2 reload all

# Очистка логов
pm2 flush

# Экспорт конфигурации
pm2 ecosystem
```

## ✅ **Преимущества PM2:**

- 🔄 **Автоперезапуск** при сбоях
- 📊 **Мониторинг** CPU и памяти
- 📋 **Централизованные логи**
- 🔧 **Управление** несколькими процессами
- 💾 **Сохранение** конфигурации
- 🚀 **Автозапуск** при перезагрузке сервера

## 🎯 **Готово к развертыванию!**

Проект полностью настроен для запуска через PM2 на VPS сервере 93.127.214.183.

**Просто выполните:**
```bash
chmod +x start_pm2.sh stop_pm2.sh view_pm2_logs.sh
./start_pm2.sh
```
