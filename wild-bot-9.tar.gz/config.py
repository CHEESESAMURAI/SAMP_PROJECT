# config.py
# Конфигурация для Wild Analytics Dashboard

# Telegram Bot Configuration
BOT_TOKEN = "your_telegram_bot_token_here"
ADMIN_ID = 123456789  # Ваш Telegram ID

# API Keys
SERPER_API_KEY = "your_serper_api_key_here"
OPENAI_API_KEY = "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"
MPSTATS_API_KEY = "68431d2ac72ea4.96910328a56006b24a55daf65db03835d5fe5b4d"
YOUTUBE_API_KEY = "your_youtube_api_key_here"
VK_SERVICE_KEY = "your_vk_service_key_here" 