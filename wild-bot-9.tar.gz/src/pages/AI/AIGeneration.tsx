import React from 'react';
import ComingSoonPage from '../ComingSoonPage';

const AIGeneration: React.FC = () => {
  return <ComingSoonPage title="AI Генерация контента" />;
};

export default AIGeneration; 