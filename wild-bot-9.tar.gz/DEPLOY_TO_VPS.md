# 🚀 Развертывание Wild Analytics Dashboard на VPS

## ✅ **Проект готов к развертыванию!**

Все файлы созданы и протестированы локально.

## 📁 **Структура проекта для VPS:**

```
WILD-BOT 9/
├── start_server.sh          # 🚀 Скрипт запуска (обычный)
├── stop_server.sh           # 🛑 Скрипт остановки (обычный)
├── view_logs.sh             # 📋 Просмотр логов (обычный)
├── start_pm2.sh             # 🚀 Скрипт запуска (PM2)
├── stop_pm2.sh              # 🛑 Скрипт остановки (PM2)
├── view_pm2_logs.sh         # 📋 Просмотр логов (PM2)
├── ecosystem.config.js      # ⚙️ Конфигурация PM2
├── requirements.txt         # 📦 Python зависимости
├── wild-analytics.service   # 🔧 Systemd сервис
├── VPS_SETUP.md            # 📖 Подробная инструкция
├── README_VPS.md           # 📖 Краткая инструкция
├── PM2_DEPLOYMENT.md       # 📖 Инструкция PM2
├── logs/                   # 📋 Папка для логов
├── web-dashboard/          # 🔧 Backend
│   └── backend/
│       ├── main.py
│       ├── config.py
│       └── ...
└── wild-analytics-web/     # 🌐 Frontend
    ├── package.json
    ├── src/
    └── ...
```

## 🚀 **Варианты запуска на VPS (93.127.214.183):**

### **Вариант 1: PM2 (Рекомендуется) 🏆**

PM2 обеспечивает профессиональное управление процессами с автоперезапуском, мониторингом и логированием.

```bash
# 1. Установка PM2
npm install -g pm2 serve

# 2. Подготовка проекта
conda create -n wildbot python=3.9 -y
conda activate wildbot
pip install -r requirements.txt
cd wild-analytics-web && npm install && npm run build && cd ..

# 3. Запуск через PM2
chmod +x start_pm2.sh stop_pm2.sh view_pm2_logs.sh
./start_pm2.sh
```

**Или прямыми командами:**
```bash
# Backend
pm2 start "python3 main.py" \
  --name wild-backend \
  --cwd /root/WILD_BOT_9/web-dashboard/backend \
  --interpreter /root/miniconda3/envs/wildbot/bin/python3

# Frontend
pm2 start serve \
  --name wild-frontend \
  -- -s build -l 3000 \
  --cwd /root/WILD_BOT_9/wild-analytics-web
```

### **Вариант 2: Обычный запуск**

```bash
# 1. Установка зависимостей
conda create -n wildbot python=3.9 -y
conda activate wildbot
pip install -r requirements.txt
cd wild-analytics-web && npm install && cd ..

# 2. Запуск проекта
chmod +x start_server.sh stop_server.sh view_logs.sh
./start_server.sh
```

## 🌐 **Результат:**

После успешного запуска:
- **Frontend**: http://93.127.214.183:3000
- **Backend**: http://93.127.214.183:8000
- **API Docs**: http://93.127.214.183:8000/docs

## 🔧 **Управление:**

### PM2 (Вариант 1):
```bash
./start_pm2.sh      # Запуск
./stop_pm2.sh       # Остановка
./view_pm2_logs.sh  # Логи и статус
pm2 status          # Статус процессов
pm2 logs            # Просмотр логов
pm2 monit           # Мониторинг
```

### Обычный (Вариант 2):
```bash
./start_server.sh   # Запуск
./stop_server.sh    # Остановка
./view_logs.sh      # Логи и статус
```

## 📊 **Автозапуск при перезагрузке:**

### PM2:
```bash
pm2 startup
pm2 save
```

### Systemd:
```bash
sudo cp wild-analytics.service /etc/systemd/system/
sudo systemctl enable wild-analytics
sudo systemctl start wild-analytics
```

## 🔍 **Устранение неполадок:**

### Проблема: Порт занят
```bash
# PM2
pm2 stop all && pm2 delete all
./start_pm2.sh

# Обычный
./stop_server.sh
sleep 5
./start_server.sh
```

### Проблема: Conda не найдена
```bash
source ~/miniconda3/etc/profile.d/conda.sh
conda activate wildbot
```

### Проблема: Зависимости не установлены
```bash
pip install -r requirements.txt
cd wild-analytics-web && npm install
```

## ✅ **Что протестировано:**

- ✅ Скрипты запуска/остановки работают (оба варианта)
- ✅ Backend сервер запускается на порту 8000
- ✅ Frontend сервер запускается на порту 3000
- ✅ Все зависимости указаны в requirements.txt
- ✅ PM2 конфигурация настроена
- ✅ Systemd сервис настроен для автозапуска
- ✅ Логирование и мониторинг настроены

## 🎯 **Рекомендация:**

**Используйте PM2** для профессионального управления процессами на продакшене.

**Преимущества PM2:**
- 🔄 Автоматический перезапуск при сбоях
- 📊 Мониторинг в реальном времени
- 📋 Централизованное логирование
- 🔧 Управление несколькими процессами
- 💾 Сохранение конфигурации

## 🚀 **Готово к развертыванию!**

Проект полностью подготовлен для запуска на VPS сервере 93.127.214.183.

**Для PM2 (рекомендуется):**
```bash
chmod +x start_pm2.sh stop_pm2.sh view_pm2_logs.sh
./start_pm2.sh
```

**Для обычного запуска:**
```bash
chmod +x start_server.sh stop_server.sh view_logs.sh
./start_server.sh
```
